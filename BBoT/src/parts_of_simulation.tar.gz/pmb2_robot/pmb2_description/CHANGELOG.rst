^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pmb2_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.9 (2018-05-09)
------------------
* Add upload.launch
* Further urdf updates
* Additional wheel collision and transmission fixes
* Fix collision and friction issues
  Work from andrei@pasnicen.co
* updated license
* fix standalone public sim of pmb2
* Merge branch 'indigo-devel' of https://github.com/pal-robotics/pmb2_robot into indigo-devel
  Conflicts:
  pmb2_bringup/package.xml
  pmb2_controller_configuration/package.xml
  pmb2_description/package.xml
  pmb2_robot/package.xml
* commit version 0.2.1
  Update maintainer email
  commit version 0.2.1
* Update maintainer email
* Stabilize stand-still
* Contributors: Bence Magyar, Jordi Pages, Procópio Stein, Victor Lopez

0.1.0 (2015-07-10)
------------------
* Add changelogs
* July sync
* Contributors: Bence Magyar
