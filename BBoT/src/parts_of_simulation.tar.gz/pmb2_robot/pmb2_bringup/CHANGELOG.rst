^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pmb2_bringup
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.9 (2018-05-09)
------------------
* added rviz and servoing to twist mux
* updated license
* fix standalone public sim of pmb2
* commit version 0.2.1
  Update maintainer email
  commit version 0.2.1
* Update maintainer email
* Contributors: Bence Magyar, Jordi Pages, Procópio Stein

0.1.0 (2015-07-10)
------------------
* Add changelogs
* July sync
* Contributors: Bence Magyar
