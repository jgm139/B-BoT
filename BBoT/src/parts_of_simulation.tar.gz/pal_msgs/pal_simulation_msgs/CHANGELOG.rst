^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pal_simulation_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.12.8 (2018-10-31)
-------------------

0.12.7 (2018-06-01)
-------------------
* Fix pal_simulation_msgs version
* Merge branch 'as_new_msgs' into 'dubnium-devel'
  + pal_simulation_msgs, pal_control_msgs/OperationalSpaceGoal
  See merge request common/pal_msgs!17
* + pal_simulation_msgs, pal_control_msgs/OperationalSpaceGoal
* Contributors: Victor Lopez, alexandersherikov
