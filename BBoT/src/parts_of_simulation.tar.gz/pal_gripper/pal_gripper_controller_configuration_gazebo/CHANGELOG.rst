^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pal_gripper_controller_configuration_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2018-07-30)
------------------

0.0.13 (2018-04-13)
-------------------

0.0.12 (2018-02-20)
-------------------

0.0.11 (2018-01-24)
-------------------
* fix installation rule
* Contributors: Jordi Pages

0.0.10 (2018-01-24)
-------------------
* move scripts and config files from tiago_robot
* Contributors: Jordi Pages
