pal_gripper related packages

![Gripper image](gazebo_screenshot.png)

Contains:

* pal_gripper_description: with its URDF and test files.
* pal_gripper_controller_configuration: with some example configuration.
* pal_gripper_gazebo: example launch of a robot formed by only the gripper.
