play_motion
===========

This repository consists of `play_motion`, a tool to play and handle
pre-recorded motions, and its associated messages in `play_motion_msgs`

Have a look at the main 
[README](https://github.com/pal-robotics/play_motion/blob/hydro-devel/play_motion/README.md) file
to see how it works.

[![Build Status](http://jenkins.ros.org/job/devel-hydro-play_motion/badge/icon)](http://jenkins.ros.org/job/devel-hydro-play_motion/)
