^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package gripper_action_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.1 (2018-01-10)
------------------
* removed changelogs
* consistent package versions
* Contributors: Hilario Tome

0.3.2 (2018-01-12)
------------------

0.3.3 (2018-03-14)
------------------

0.3.4 (2018-03-28)
------------------

0.3.5 (2018-04-05)
------------------

0.3.6 (2018-05-02)
------------------

0.3.7 (2018-05-07)
------------------

0.3.8 (2018-05-08)
------------------

0.3.9 (2018-05-29)
------------------

0.3.10 (2018-06-15)
-------------------

0.3.11 (2018-06-19)
-------------------

0.13.1 (2017-11-06)
-------------------
* Update changelogs
* Contributors: Bence Magyar

0.13.0 (2017-08-10)
-------------------
* Update changelogs
* Contributors: Bence Magyar

0.12.3 (2017-04-23)
-------------------
* Update changelogs
* Contributors: Bence Magyar

0.12.2 (2017-04-21)
-------------------
* Update changelogs
* Contributors: Bence Magyar

0.12.1 (2017-03-08)
-------------------
* Update changelogs
* Contributors: Bence Magyar

0.12.0 (2017-02-15)
-------------------
* Update changelogs
* Merge pull request #242 from bmagyar/update_package_xmls
  Update package xmls
* Fix most catkin lint issues
* Change for format2
* Cleanup boilerplate
* Add Enrique and Bence to maintainers
* Merge pull request #237 from bmagyar/unboost-urdf-last-bit
  urdf::Model typedefs had to be added to a different repo first
* urdf::Model typedefs had to be added to a different repo first
* Merge branch 'kinetic-devel' into F_enable_part_traj_kinetic
* Merge pull request #235 from bmagyar/unboost-urdf-fix
  Replace boost::shared_ptr<urdf::XY> with urdf::XYConstSharedPtr when exists
* Replace boost::shared_ptr<urdf::XY> with urdf::XYConstSharedPtr when exists
* Contributors: Bence Magyar, Enrique Fernández Perdomo, beatrizleon

0.11.2 (2016-08-16)
-------------------
* Update changelogs
* Contributors: Bence Magyar

0.11.1 (2016-05-23)
-------------------
* Update changelogs
* Contributors: Bence Magyar

0.11.0 (2016-05-03)
-------------------
* Update changelogs
* Contributors: Bence Magyar

0.10.0 (2015-11-20)
-------------------
* Update changelogs
* Contributors: Adolfo Rodriguez Tsouroukdissian

0.9.2 (2015-05-04)
------------------
* Update changelogs.
* Contributors: Adolfo Rodriguez Tsouroukdissian

0.9.1 (2014-11-03)
------------------
* Update changelogs
* Contributors: Adolfo Rodriguez Tsouroukdissian

0.9.0 (2014-10-31)
------------------
* Update changelogs
* Merge pull request #133 from pal-robotics/catkin-lint-fixes
  Buildsystem fixes suggested by catkin_lint
* Buildsystem fixes suggested by catkin_lint
* Merge pull request #113 from bulwahn/indigo-devel
  addressing test dependencies with -DCATKIN_ENABLE_TESTING=0
* gripper_action_controller: drop unneeded rostest dependency
* Contributors: Adolfo Rodriguez Tsouroukdissian, Lukas Bulwahn

0.8.1 (2014-07-11)
------------------
* Update chegelogs
* Contributors: Adolfo Rodriguez Tsouroukdissian

0.8.0 (2014-05-12)
------------------
* Updated changelogs
* Contributors: Dave Coleman

0.7.2 (2014-04-01)
------------------
* Prepare 0.7.2
* Merge pull request #86 from cottsay/hydro-devel
  Add missing deps to package.xml
* Added missing deps to package.xml
* Contributors: Adolfo Rodriguez Tsouroukdissian, Scott K Logan

0.7.1 (2014-03-31)
------------------
* Prepare 0.7.1
* 0.7.0
* gripper_action_controller: bump version to 0.6.0
  To match the rest of `ros_controllers`
* Create changelog files for new packages.
* Merge pull request #79 from sachinchitta/hydro-devel
  adding simple gripper action controller for single dof grippers
* renamed commanded_effort since it could represent position as well
* Update gripper_action_controller.cpp
* Update package.xml
* adding simple gripper action controller for single dof grippers
* Contributors: Adolfo Rodriguez Tsouroukdissian, Sachin Chitta

0.6.0 (2014-02-05)
------------------

0.5.4 (2013-09-30)
------------------

0.5.3 (2013-09-04)
------------------

0.5.2 (2013-08-06)
------------------

0.5.1 (2013-07-19)
------------------

0.5.0 (2013-07-16)
------------------

0.4.0 (2013-06-26)
------------------
