# tiago_robot

For more information please refer to http://wiki.ros.org/Robots/TIAGo

For technical questions please write to tiago-support@pal-robotics.com

<img src="http://wiki.ros.org/Robots/TIAGo?action=AttachFile&do=get&target=TIAGo_titanium_right.png" width="350"/>
