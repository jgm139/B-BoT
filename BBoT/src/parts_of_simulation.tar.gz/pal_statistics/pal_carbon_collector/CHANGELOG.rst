^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pal_carbon_collector
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.0 (2018-10-29)
------------------
* Rename dependency to python-graphitesend-pip
* Contributors: Victor Lopez

1.0.8 (2018-10-25)
------------------

1.0.7 (2018-10-25)
------------------

1.0.6 (2018-10-24)
------------------

1.0.5 (2018-10-24)
------------------

1.0.4 (2018-10-23)
------------------

1.0.3 (2018-10-23)
------------------

1.0.2 (2018-10-22)
------------------

1.0.1 (2018-10-22)
------------------

1.0.0 (2018-09-20)
------------------

0.0.3 (2018-07-25)
------------------

0.0.2 (2018-07-04)
------------------
* Merge branch 'statsd_regex' into 'erbium-devel'
  pal_statsd_collector should accept regex for statistics names
  See merge request qa/pal_statistics!2
* Added execution permissions to both nodes
* Removed rospy from CMakeLists
* Updated license
* Unified versions
* Merge branch 'master' of gitlab:qa/pal_carbon_collector into erbium-devel
* Moved files to their own package directory
* Contributors: Jordan Palacios, Victor Lopez

0.0.1 (2018-06-21)
------------------
