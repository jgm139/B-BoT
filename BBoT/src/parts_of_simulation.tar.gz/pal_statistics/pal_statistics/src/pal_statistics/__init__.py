from statistics_registry import *
