^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package tiago_2dnav_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.10 (2016-10-21)
-------------------

0.0.9 (2016-10-14)
------------------
* set a different initial pose of the robot
* set myself as maintainer
* launch files to support public map/loc
* disable dynamic_footprint when public_sim=true
* New launch file for the pick and place demo, also provided the world
* Contributors: Jordi Pages, job-1994

0.0.7 (2016-06-15)
------------------
* Change default robot type to custom
* Contributors: Victor Lopez

0.0.6 (2016-06-15)
------------------

0.0.5 (2016-06-15)
------------------

0.0.4 (2016-06-15)
------------------

0.0.3 (2016-06-14)
------------------
* default robot model
* fix default robot
* Contributors: Jeremie Deray

0.0.2 (2015-04-15)
------------------

0.0.1 (2015-04-15)
------------------
* refs #10237 : fixes default robot model to full
* Missing a d in the project name
* adds tiago_2dnav_gazebo
* Contributors: Sammy Pfeiffer, enriquefernandez
