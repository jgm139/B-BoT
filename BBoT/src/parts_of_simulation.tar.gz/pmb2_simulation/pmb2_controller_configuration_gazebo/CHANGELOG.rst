^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pmb2_controller_configuration_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2016-04-20)
------------------

0.9.7 (2016-04-15)
------------------

0.9.6 (2016-02-09)
------------------

0.9.5 (2015-10-27)
------------------
* Update maintainer
* Contributors: Bence Magyar

0.9.4 (2015-02-18)
------------------
* Make rgbd camera fixed
* Contributors: Enrique Fernandez

0.9.3 (2015-02-03)
------------------

0.9.2 (2015-02-02)
------------------
* Replace ant -> pmb2
* Rename files
* Contributors: Enrique Fernandez
