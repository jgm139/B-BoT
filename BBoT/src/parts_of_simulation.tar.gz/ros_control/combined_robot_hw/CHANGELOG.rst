^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package combined_robot_hw
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.6 (2018-01-08)
------------------
* maded package xmls consistent
* deleted changelogs
* updated changelog
* removed combined robot hw changelogs
* Merge pull request #263 from mintar/patch-1
  Fix typo in architecture.svg
* Fix typo in architecture.svg
* 0.11.4
* Update logs
* 0.11.3
* Update changelogs
* 0.11.2
* Update changelogs
* Merge pull request #254 from bmagyar/update_package_xmls
  Update package xmls
* Add Toni's email to the author fields too
* Add Enrique and Bence to maintainer list
* Clean up export leftovers from rosbuild
* Convert to format2, fix dependency in cmake
* Merge pull request #252 from bmagyar/update_metapackage
  Add combined_robot_hw to metapackage & system figure
* Add combined_robot_hw to metapackage & system figure
* 0.11.1
* Update changelog
* 0.11.0
* Fix version number
* Update changelogs
* Merge pull request #235 from shadow-robot/combined_robot_hw_kinetic
  Combined robot hw kinetic
* Add packages combined_robot_hw and combined_robot_hw_tests. combined_robot_hw allows to load different RobotHW as plugins and combines them into a single RobotHW. A single controller manager can then access resources from any robot.
* Contributors: Bence Magyar, Hilario Tome, Martin Günther, Toni Oliver

0.2.7 (2018-10-25)
------------------

0.9.3 (2015-05-05)
------------------

0.9.2 (2015-05-04)
------------------

0.9.1 (2014-11-03)
------------------

0.9.0 (2014-10-31)
------------------

0.8.2 (2014-06-25)
------------------

0.8.1 (2014-06-24)
------------------

0.8.0 (2014-05-12)
------------------

0.7.2 (2014-04-01)
------------------

0.7.1 (2014-03-31)
------------------

0.7.0 (2014-03-28)
------------------

0.6.0 (2014-02-05)
------------------

0.5.8 (2013-10-11)
------------------

0.5.7 (2013-07-30)
------------------

0.5.6 (2013-07-29)
------------------

0.5.5 (2013-07-23 17:04)
------------------------

0.5.4 (2013-07-23 14:37)
------------------------

0.5.3 (2013-07-22 18:06)
------------------------

0.5.2 (2013-07-22 15:00)
------------------------

0.5.1 (2013-07-19)
------------------

0.5.0 (2013-07-16)
------------------

0.4.0 (2013-06-25)
------------------
