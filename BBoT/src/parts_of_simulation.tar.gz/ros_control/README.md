ros_control
===========

See [ros_control documentation](http://ros.org/wiki/ros_control) on ros.org

### Build Status

[![Build Status](https://travis-ci.org/ros-controls/ros_control.png?branch=hydro-devel)](https://travis-ci.org/ros-controls/ros_control)