# -*- coding: utf-8 -*-

import os
import shutil
from os import walk, getcwd
from PIL import Image

classes = ["coke_can", "bowl", "beer", "table", "wall", "seat", "bookshelf", "pringles"]

"""-------------------------------------------------------------------"""

""" Configure Paths"""
mypath_label = "./Labels/008/"
mypath_image = "./Images/008/"
current_class = 8
is_mixed = False

""" Get input text file list """
os.system('rm -r ./Labels/*/.DS_Store')
txt_list = []
for (dirpath, dirnames, filenames) in walk(mypath_label):
    txt_list.extend(filenames)
    break

""" Process """
for txt_name in txt_list:
    print("The current txt is " + txt_name)
    """ Open input text files """
    txt_path = mypath_label + txt_name
    txt_file = open(txt_path, "r")
    split_image = txt_name.split('.')
    image = split_image[0] + ".jpg"
    print("The current image is " + mypath_image + image)
    # "I m a g e -"
    split_number = split_image[0]
    image_number = split_number[5:]
    print("The image number is " + image_number)
    if len(image_number) < 3:
        lines = txt_file.read().split('\n')

        print(lines[0])
        num_objects_file = int(lines[0])
        original_objects = []
        final_objects = []

        if num_objects_file > 1:
            print("There are some objects")
            for line in lines[1:-1]:
                elems = line.split(' ')
                original_objects.append(elems)

            for object in original_objects:
                #print(object)
                if object[4] not in classes:
                    exit(0)

                object_class = classes.index(object[4]) + 1
                if object_class != current_class:
                    # is_mixed = True
                    object_image_directory = "./Images/00" + str(object_class) + "/"
                    object_txt_directory = "./Labels/00" + str(object_class) + "/"

                    new_file = "Image" + str(current_class) + str(object_class) + str(image_number)
                    new_image = object_image_directory + new_file + ".jpg"
                    new_txt = object_txt_directory + new_file + ".txt"

                    shutil.copy(mypath_image + image, new_image)

                    """ Open output text files """
                    txt_outfile = open(new_txt, "w+")
                    txt_outfile.write(' '.join(object) + '\n')
                    txt_outfile.close();
                else:
                    final_objects.append(object)
        else:
            elems = lines[1].split(' ')
            final_objects.append(elems)

        txt_file.close()

        # if is_mixed:
        txt_file = open(txt_path, "w+")
        for final_object in final_objects:
            txt_file.write(' '.join(final_object) + '\n')

        # is_mixed = False
        txt_file.close()
    else:
        print("It is a new image, not process")
        txt_file.close()
