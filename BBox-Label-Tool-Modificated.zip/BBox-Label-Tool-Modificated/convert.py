# -*- coding: utf-8 -*-

import os
from os import walk, getcwd
from PIL import Image

classes = ["001","002","003","004","005","006","007","008"]
name_objects = ["coke_can", "bowl", "beer", "table", "wall", "seat", "bookshelf", "pringles"]

def convert(size, box):
    dw = 1./size[0]
    dh = 1./size[1]
    x = (box[0] + box[1])/2.0
    y = (box[2] + box[3])/2.0
    w = box[1] - box[0]
    h = box[3] - box[2]
    x = x*dw
    w = w*dw
    y = y*dh
    h = h*dh
    return (x,y,w,h)


"""-------------------------------------------------------------------"""

""" Configure Paths"""
mypath = "./Labels/008/"
outpath = "./Labels/008/output/"

cls = "008"
if cls not in classes:
    exit(0)
cls_id = classes.index(cls)

"---The method getcwd() returns current working directory of a process.---"
wd = getcwd()
list_file = open('%s/%s_list.txt'%(wd, cls), 'w')

""" Get input text file list """
txt_name_list = []
for (dirpath, dirnames, filenames) in walk(mypath):
    txt_name_list.extend(filenames)
    break
# print(txt_name_list)

""" Process """
for txt_name in txt_name_list:

    """ Open input text files """
    txt_path = mypath + txt_name
    print("Input:" + txt_path)
    txt_file = open(txt_path, "r")
    lines = txt_file.read().split('\n')   #for ubuntu, use "\r\n" instead of "\n"

    """ Open output text files """
    txt_outpath = outpath + txt_name
    print("Output:" + txt_outpath)
    txt_outfile = open(txt_outpath, "a")


    """ Convert the data to YOLO format """
    ct = 0
    for line in lines:
        elems = line.split(' ')
        if(len(elems) >= 2):
            ct = ct + 1
            print(line + "\n")
            elems = line.split(' ')
            print(elems)
            xmin = elems[0]
            xmax = elems[2]
            ymin = elems[1]
            ymax = elems[3]
            if elems[4] not in name_objects:
                exit(0)
            class_number = name_objects.index(elems[4])
            print(elems[0])
            #
            img_path = str('%s/Images/%s/%s.jpg'%(wd, cls, os.path.splitext(txt_name)[0]))
            im=Image.open(img_path)
            w= int(im.size[0])
            h= int(im.size[1])
            print(w, h)
            print(float(xmin), float(xmax), float(ymin), float(ymax))
            b = (float(xmin), float(xmax), float(ymin), float(ymax))
            bb = convert((w,h), b)
            print(bb)
            txt_outfile.write(str(class_number) + " " + " ".join([str(a) for a in bb]) + '\n')

    """ Save those images with bb into list"""
    if(ct != 0):
        # list_file.write('%s/Images/%s/%s.jpg\n'%(wd, cls, os.path.splitext(txt_name)[0]))
        list_file.write('./Images/%s/%s.jpg\n'%(cls, os.path.splitext(txt_name)[0]))

list_file.close()
